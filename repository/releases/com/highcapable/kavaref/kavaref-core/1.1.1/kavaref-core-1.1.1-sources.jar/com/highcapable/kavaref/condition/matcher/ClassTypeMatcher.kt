/*
 * KavaRef - A modernizing Java Reflection with Kotlin.
 * Copyright (C) 2019 HighCapable
 * https://github.com/HighCapable/KavaRef
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2025/5/20.
 */
package com.highcapable.kavaref.condition.matcher

import com.highcapable.kavaref.condition.matcher.base.TypeMatcher
import java.lang.reflect.Type

/**
 * A [TypeMatcher] that matches a specific class type.
 * @param clazz the class type to match.
 */
data class ClassTypeMatcher(
    val clazz: Class<*>
) : TypeMatcher {

    override fun matches(type: Type) = type == clazz
}