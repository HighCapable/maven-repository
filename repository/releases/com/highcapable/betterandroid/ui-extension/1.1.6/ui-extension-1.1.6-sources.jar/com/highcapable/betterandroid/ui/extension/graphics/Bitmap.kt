/*
 * Better Android - Create more useful tool extensions for Android.
 * Copyright (C) 2019 HighCapable
 * https://github.com/BetterAndroid/BetterAndroid
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2023/10/26.
 */
@file:Suppress("unused")
@file:JvmName("BitmapUtils")

package com.highcapable.betterandroid.ui.extension.graphics

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.annotation.Px
import androidx.core.graphics.scale
import com.highcapable.betterandroid.ui.extension.component.base.toHexResourceId
import com.highcapable.betterandroid.ui.extension.graphics.base.BitmapBlurFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileDescriptor
import java.io.InputStream
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Decode a file into a bitmap.
 *
 * If you cannot be decoded into a bitmap, will throw an exception.
 * @see File.decodeToBitmapOrNull
 * @see BitmapFactory.decodeFile
 * @receiver [File]
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap]
 * @throws IllegalStateException if the bitmap decode failed.
 */
@JvmOverloads
fun File.decodeToBitmap(opts: BitmapFactory.Options? = null) =
    decodeToBitmapOrNull(opts) ?: error("Unable to decode file $absolutePath of a bitmap.")

/**
 * Decode a file descriptor into a bitmap.
 *
 * If you cannot be decoded into a bitmap, will throw an exception.
 * @see FileDescriptor.decodeToBitmapOrNull
 * @see BitmapFactory.decodeFileDescriptor
 * @receiver [FileDescriptor]
 * @param outPadding set the padding of this bitmap, default is null.
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap]
 * @throws IllegalStateException if the bitmap decode failed.
 */
@JvmOverloads
fun FileDescriptor.decodeToBitmap(outPadding: Rect? = null, opts: BitmapFactory.Options? = null) =
    decodeToBitmapOrNull(outPadding, opts) ?: error("Unable to decode file descriptor $this of a bitmap.")

/**
 * Decode a stream into a bitmap.
 *
 * If you cannot be decoded into a bitmap, will throw an exception.
 * @see InputStream.decodeToBitmapOrNull
 * @see BitmapFactory.decodeStream
 * @receiver [InputStream]
 * @param outPadding set the padding of this bitmap, default is null.
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap]
 * @throws IllegalStateException if the bitmap decode failed.
 */
@JvmOverloads
fun InputStream.decodeToBitmap(outPadding: Rect? = null, opts: BitmapFactory.Options? = null) =
    decodeToBitmapOrNull(outPadding, opts) ?: error("Unable to decode stream $this of a bitmap.")

/**
 * Decode a byte array into a bitmap.
 *
 * If you cannot be decoded into a bitmap, will throw an exception.
 * @see ByteArray.decodeToBitmapOrNull
 * @see BitmapFactory.decodeByteArray
 * @receiver [ByteArray]
 * @param offset the current offset, default is 0.
 * @param size the current data length, default is [ByteArray.size].
 * @return [Bitmap]
 * @throws IllegalStateException if the bitmap decode failed.
 */
@JvmOverloads
fun ByteArray.decodeToBitmap(offset: Int = 0, size: Int = this.size) =
    decodeToBitmapOrNull(offset, size) ?: error("Unable to decode byte array $this of a bitmap.")

/**
 * Create a bitmap from resources.
 *
 * If you cannot be decoded into a bitmap, will throw an exception.
 * @see Resources.createBitmapOrNull
 * @see BitmapFactory.decodeResource
 * @receiver [Resources]
 * @param resId the drawable resource id.
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap]
 * @throws IllegalStateException if the bitmap decode failed.
 */
@JvmOverloads
fun Resources.createBitmap(@DrawableRes resId: Int, opts: BitmapFactory.Options? = null) =
    createBitmapOrNull(resId, opts) ?: error("Unable to create a bitmap from resource ID ${resId.toHexResourceId()}.")

/**
 * Decode a file into a bitmap.
 *
 * If you cannot be decoded into a bitmap, the function returns null.
 * @see BitmapFactory.decodeFile
 * @receiver [File]
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap] or null.
 */
@JvmOverloads
fun File.decodeToBitmapOrNull(opts: BitmapFactory.Options? = null) =
    runCatching { BitmapFactory.decodeFile(absolutePath, opts) }.getOrNull()

/**
 * Decode a file descriptor into a bitmap.
 *
 * If you cannot be decoded into a bitmap, the function returns null.
 * @see BitmapFactory.decodeFileDescriptor
 * @receiver [FileDescriptor]
 * @param outPadding set the padding of this bitmap, default is null, see [BitmapFactory.decodeFileDescriptor].
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap] or null.
 */
@JvmOverloads
fun FileDescriptor.decodeToBitmapOrNull(outPadding: Rect? = null, opts: BitmapFactory.Options? = null) =
    runCatching { BitmapFactory.decodeFileDescriptor(this, outPadding, opts) }.getOrNull()

/**
 * Decode a stream into a bitmap.
 *
 * If you cannot be decoded into a bitmap, the function returns null.
 * @see BitmapFactory.decodeStream
 * @receiver [InputStream]
 * @param outPadding set the padding of this bitmap, default is null.
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap] or null.
 */
@JvmOverloads
fun InputStream.decodeToBitmapOrNull(outPadding: Rect? = null, opts: BitmapFactory.Options? = null) =
    runCatching { BitmapFactory.decodeStream(this, outPadding, opts) }.getOrNull()

/**
 * Decode a byte array into a bitmap.
 *
 * If you cannot be decoded into a bitmap, the function returns null.
 * @see BitmapFactory.decodeByteArray
 * @receiver [ByteArray]
 * @param offset the current offset, default is 0.
 * @param size the current data length, default is [ByteArray.size].
 * @return [Bitmap] or null.
 */
@JvmOverloads
fun ByteArray.decodeToBitmapOrNull(offset: Int = 0, size: Int = this.size) =
    runCatching { BitmapFactory.decodeByteArray(this, offset, size) }.getOrNull()

/**
 * Create a bitmap from resources.
 *
 * If you cannot be decoded into a bitmap, the function returns null.
 * @see BitmapFactory.decodeResource
 * @receiver [Resources]
 * @param resId the drawable resource id.
 * @param opts the [BitmapFactory.Options], default is null.
 * @return [Bitmap] or null.
 */
@JvmOverloads
fun Resources.createBitmapOrNull(@DrawableRes resId: Int, opts: BitmapFactory.Options? = null) =
    runCatching { BitmapFactory.decodeResource(this, resId, opts) }.getOrNull()

/**
 * Save the bitmap to file.
 * @see OutputStream.compressBitmap
 * @receiver [File]
 * @param bitmap the current bitmap.
 * @param format the bitmap format, default is [Bitmap.CompressFormat.JPEG].
 * @param quality the quality, default is 100.
 */
@JvmOverloads
fun File.writeBitmap(bitmap: Bitmap, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 100) {
    createNewFile()
    outputStream().use { it.compressBitmap(bitmap, format, quality) }
}

/**
 * Compress the bitmap to the output stream.
 * @see File.writeBitmap
 * @receiver [OutputStream]
 * @param bitmap the current bitmap.
 * @param format the bitmap format, default is [Bitmap.CompressFormat.JPEG].
 * @param quality the quality, default is 100.
 * @return [Boolean] whether the bitmap compress success.
 */
@JvmOverloads
fun OutputStream.compressBitmap(bitmap: Bitmap, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 100) =
    bitmap.compress(format, quality, this)

/**
 * Blur the bitmap using [BitmapBlurFactory].
 *
 * In Android 12 and above, you can use the blur solution provided by the system.
 * @receiver [Bitmap]
 * @param radius the blur radius.
 * @return [Bitmap]
 */
fun Bitmap.blur(radius: Int) = BitmapBlurFactory.process(this, radius)

/**
 * Convert the bitmap to a round corner bitmap.
 * @receiver [Bitmap]
 * @param radii the radius of the 4 corners (px).
 * @param backgroundColor the background color, default is [Color.WHITE].
 * @param config the config, default is [Bitmap.Config.ARGB_8888].
 * @return [Bitmap]
 * @throws IllegalArgumentException if the length of the radii array is not 8 or throws by [Bitmap.createBitmap].
 */
@JvmOverloads
fun Bitmap.round(@Px radii: FloatArray, @ColorInt backgroundColor: Int = Color.WHITE, config: Bitmap.Config = Bitmap.Config.ARGB_8888): Bitmap {
    require(radii.size == 8) { "The length of the radii array must be 8." }

    return Bitmap.createBitmap(width, height, config).also { outBitmap ->
        val canvas = Canvas(outBitmap)
        val paint = Paint()

        paint.isAntiAlias = true
        canvas.drawARGB(0, 0, 0, 0)
        paint.color = backgroundColor

        val path = Path()
        path.addRoundRect(RectF(Rect(0, 0, width, height)), radii, Path.Direction.CW)

        canvas.drawPath(path, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(this, Rect(0, 0, width, height), Rect(0, 0, width, height), paint)
    }
}

/**
 * Convert the bitmap to a round corner bitmap.
 * @receiver [Bitmap]
 * @param topLeft the radius of the top-left corner (px).
 * @param topRight the radius of the top-right corner (px).
 * @param bottomLeft the radius of the bottom-right corner (px).
 * @param bottomRight the radius of the bottom-left corner (px).
 * @param backgroundColor the background color, default is [Color.WHITE].
 * @param config the config, default is [Bitmap.Config.ARGB_8888].
 * @return [Bitmap]
 */
@JvmOverloads
@JvmName("roundRadii")
fun Bitmap.round(
    @Px topLeft: Float = 0f,
    @Px topRight: Float = 0f,
    @Px bottomLeft: Float = 0f,
    @Px bottomRight: Float = 0f,
    @ColorInt backgroundColor: Int = Color.WHITE,
    config: Bitmap.Config = Bitmap.Config.ARGB_8888
) = round(floatArrayOf(topLeft, topLeft, topRight, topRight, bottomRight, bottomRight, bottomLeft, bottomLeft), backgroundColor, config)

/**
 * Convert the bitmap to a round corner bitmap.
 * @receiver [Bitmap]
 * @param radius the round corner (px).
 * @param backgroundColor the background color, default is [Color.WHITE].
 * @param config the config, default is [Bitmap.Config.ARGB_8888].
 * @return [Bitmap]
 */
@JvmOverloads
fun Bitmap.round(
    @Px radius: Float,
    @ColorInt backgroundColor: Int = Color.WHITE,
    config: Bitmap.Config = Bitmap.Config.ARGB_8888
) = round(radius, radius, radius, radius, backgroundColor, config)

/**
 * Shrink the bitmap to reduce its size.
 * @receiver [Bitmap]
 * @param maxSize the allowed maximum size.
 * @param format the bitmap format, default is [Bitmap.CompressFormat.JPEG].
 * @param quality the quality, default is 100.
 * @return [Bitmap]
 */
@JvmOverloads
fun Bitmap.shrink(maxSize: Float, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG, quality: Int = 100): Bitmap {
    if (maxSize <= 0f) return this

    var outBitmap = this
    ByteArrayOutputStream().use {
        if (!outBitmap.compress(format, quality, it)) return outBitmap

        val baosByte = it.toByteArray()
        val mid = baosByte.size / 1024.0

        if (mid > maxSize) {
            val size = mid / maxSize

            val floatWidth = (width / sqrt(size)).toFloat()
            val floatHeight = (height / sqrt(size)).toFloat()
            outBitmap = outBitmap.scale(max(1, floatWidth.toInt()), max(1, floatHeight.toInt()))
        }
    }

    return outBitmap
}

/**
 * Reduce the bitmap width and height.
 * @see Bitmap.scale
 * @receiver [Bitmap]
 * @param multiple the reduce multiple, default is 2.
 * @return [Bitmap]
 */
@JvmOverloads
fun Bitmap.reduce(multiple: Int = 2): Bitmap {
    if (multiple <= 1) return this

    val sWidth = max(1, width / multiple)
    val sHeight = max(1, height / multiple)

    return scale(sWidth, sHeight)
}