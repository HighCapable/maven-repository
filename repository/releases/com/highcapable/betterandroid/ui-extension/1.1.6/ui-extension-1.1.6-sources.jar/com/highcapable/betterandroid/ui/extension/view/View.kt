/*
 * Better Android - Create more useful tool extensions for Android.
 * Copyright (C) 2019 HighCapable
 * https://github.com/BetterAndroid/BetterAndroid
 *
 * Apache License Version 2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * This file is created by fankes on 2023/10/25.
 */
@file:Suppress("unused", "FunctionName", "EXTENSION_SHADOWED_BY_MEMBER", "AssignedValueIsNeverRead")
@file:JvmName("ViewUtils")

package com.highcapable.betterandroid.ui.extension.view

import android.app.Activity
import android.graphics.Outline
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.ViewPropertyAnimator
import android.view.inputmethod.InputMethodManager
import androidx.annotation.Px
import androidx.appcompat.widget.TooltipCompat
import androidx.core.content.getSystemService
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ancestors
import androidx.core.view.children
import androidx.core.view.descendants
import androidx.core.view.marginBottom
import androidx.core.view.marginEnd
import androidx.core.view.marginLeft
import androidx.core.view.marginRight
import androidx.core.view.marginStart
import androidx.core.view.marginTop
import androidx.core.view.setMargins
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMargins
import androidx.core.view.updateMarginsRelative
import androidx.core.view.updatePadding
import androidx.core.view.updatePaddingRelative
import com.highcapable.betterandroid.system.extension.utils.AndroidVersion
import com.highcapable.betterandroid.ui.extension.R
import com.highcapable.betterandroid.ui.extension.component.hostActivity
import com.highcapable.kavaref.extension.classOf
import com.highcapable.kavaref.extension.createInstanceOrNull
import kotlin.reflect.KClass

/**
 * Get the view's location on screen.
 * @receiver [View]
 * @return [Point]
 */
val View.location
    get() = runCatching {
        val locations = IntArray(2)

        getLocationInWindow(locations)
        Point(locations[0], locations[1])
    }.getOrNull() ?: Point()

/**
 * Get the view's tag.
 * @receiver [View]
 * @return [T] or null.
 */
inline fun <reified T> View.tag() = tag as? T?

/**
 * Get the view's tag.
 * @receiver [View]
 * @param key the key name.
 * @param default the default value.
 * @return [T]
 */
inline fun <reified T> View.getTag(key: Int, default: T) = getTag<T>(key) ?: default

/**
 * Get the view's tag.
 * @receiver [View]
 * @param key the key name.
 * @return [T] or null.
 */
inline fun <reified T> View.getTag(key: Int) = getTag(key) as? T?

/**
 * Get the view's parent view [VG].
 * @see ViewGroup.parentOrNull
 * @receiver [View]
 * @return [VG]
 * @throws IllegalStateException if the parent view is not a type of [VG] or is null.
 */
@JvmName("parentTyped")
inline fun <reified VG : ViewGroup> View.parent() = parent as? VG?
    ?: error("This view's parent is not a type of ${classOf<VG>()} or is null.")

/**
 * Get the view's parent view [VG].
 * @see ViewGroup.parent
 * @receiver [View]
 * @return [VG] or null.
 */
@JvmName("parentOrNullTyped")
inline fun <reified VG : ViewGroup> View.parentOrNull() = parent as? VG?

/**
 * Get the view's parent view.
 * @see ViewGroup.parentOrNull
 * @receiver [View]
 * @return [ViewGroup]
 * @throws IllegalStateException if the parent view is not a type of [ViewGroup].
 */
fun View.parent() = parent<ViewGroup>()

/**
 * Get the view's parent view.
 * @see ViewGroup.parent
 * @receiver [View]
 * @return [ViewGroup] or null.
 */
fun View.parentOrNull() = parentOrNull<ViewGroup>()

/**
 * Get the view [V] by [index] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @param index the index of the view.
 * @return [V]
 * @throws IllegalStateException if the view at [index] is not a type of [V] or is null.
 */
@JvmName("childTyped")
inline fun <reified V : View> ViewGroup.child(index: Int) = getChildAt(index) as? V?
    ?: error("This view at $index is not a type of ${classOf<V>()} or is null.")

/**
 * Get the view [V] by [index] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @param index the index of the view.
 * @return [V] or null.
 */
@JvmName("childOrNullTyped")
inline fun <reified V : View> ViewGroup.childOrNull(index: Int) = getChildAt(index) as? V?

/**
 * Get the first child view [V] in its parent view.
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [V]
 * @throws IllegalStateException if the first child view is not a type of [V] or is null.
 */
inline fun <reified V : View> ViewGroup.firstChild() = child<V>(index = 0)

/**
 * Get the last child view [V] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [V]
 * @throws IllegalStateException if the last child view is not a type of [V] or is null.
 */
inline fun <reified V : View> ViewGroup.lastChild() = child<V>(index = childCount - 1)

/**
 * Get the first child view [V] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [V] or null.
 */
inline fun <reified V : View> ViewGroup.firstChildOrNull() = childOrNull<V>(index = 0)

/**
 * Get the last child view [V] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.lastChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [V] or null.
 */
inline fun <reified V : View> ViewGroup.lastChildOrNull() = childOrNull<V>(index = childCount - 1)

/**
 * Get the view by [index] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @param index the index of the view.
 * @return [View]
 * @throws IllegalStateException if the view at [index] is null.
 */
fun ViewGroup.child(index: Int) = child<View>(index)

/**
 * Get the view by [index] in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @param index the index of the view.
 * @return [View] or null.
 */
fun ViewGroup.childOrNull(index: Int) = childOrNull<View>(index)

/**
 * Get the first child view in its parent view.
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [View]
 * @throws IllegalStateException if the first child view is null.
 */
val ViewGroup.firstChild get() = firstChild<View>()

/**
 * Get the last child view in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [View]
 * @throws IllegalStateException if the last child view is null.
 */
val ViewGroup.lastChild get() = lastChild<View>()

/**
 * Get the first child view in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.lastChild
 * @see ViewGroup.lastChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [View] or null.
 */
val ViewGroup.firstChildOrNull get() = firstChildOrNull<View>()

/**
 * Get the last child view in its parent view.
 * @see ViewGroup.firstChild
 * @see ViewGroup.lastChild
 * @see ViewGroup.firstChildOrNull
 * @see ViewGroup.child
 * @see ViewGroup.childOrNull
 * @see ViewGroup.getChildAt
 * @receiver [ViewGroup]
 * @return [View] or null.
 */
val ViewGroup.lastChildOrNull get() = lastChildOrNull<View>()

/**
 * Remove self from its parent view using [ViewGroup.removeView].
 * @receiver [View]
 */
fun View.removeSelf() {
    parentOrNull()?.removeView(this)
}

/**
 * Remove self from its parent view using [ViewGroup.removeViewInLayout].
 * @receiver [View]
 */
fun View.removeSelfInLayout() {
    parentOrNull()?.removeViewInLayout(this)
}

/**
 * Show the input method.
 *
 * - Note: This function may not work on Android lower than 11
 *   or when the current [View] is not in [Activity].
 * @receiver [View]
 */
fun View.showIme() {
    /** Whatever try to show the input method. */
    fun showSoftInput() {
        requestFocus()

        @Suppress("DEPRECATION")
        context?.getSystemService<InputMethodManager>()?.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    }

    val windowFromActivity = context.hostActivity?.window

    if (AndroidVersion.isAtLeast(AndroidVersion.R) && windowFromActivity != null)
        WindowCompat.getInsetsController(windowFromActivity, this).show(WindowInsetsCompat.Type.ime())
    else showSoftInput()
}

/**
 * Hide the input method.
 *
 * - Note: This function may not work on Android lower than 11
 *   or when the current [View] is not in [Activity].
 * @receiver [View]
 */
fun View.hideIme() {
    /** Whatever try to hide the input method. */
    fun hideSoftInput() {
        context?.getSystemService<InputMethodManager>()
            ?.also { if (it.isActive) it.hideSoftInputFromWindow(applicationWindowToken, 0) }
    }

    val windowFromActivity = context.hostActivity?.window

    if (AndroidVersion.isAtLeast(AndroidVersion.R) && windowFromActivity != null)
        WindowCompat.getInsetsController(windowFromActivity, this).hide(WindowInsetsCompat.Type.ime())
    else hideSoftInput()
}

/**
 * Get or set the view's tooltip text (compat).
 * 
 * If the target SDK version is lower than 26,
 * the tooltip text will be compatible with [TooltipCompat].
 * @see TooltipCompat.setTooltipText
 * @see ViewCompat.setTooltipText
 * @receiver [View]
 * @return [CharSequence] or null.
 */
var View.tooltipTextCompat
    get() = if (AndroidVersion.isAtLeast(AndroidVersion.O))
        tooltipText
    else getTag<CharSequence?>(R.id.tag_better_android_tooltip_text_compat)
    set(value) {
        if (AndroidVersion.isAtLeast(AndroidVersion.O))
            tooltipText = value
        else value?.let {
            setTag(R.id.tag_better_android_tooltip_text_compat, it)
            TooltipCompat.setTooltipText(this, value)
        }
    }

/**
 * Animate the view.
 * @receiver [View]
 * @param action the view property animator action.
 */
fun View.animate(action: ViewPropertyAnimator.() -> Unit) = animate().apply(action).start()

/**
 * Simulate the key down and up events.
 * @receiver [View]
 * @param keyCode the key code.
 * @param duration the key pressing duration time, default is 150.
 */
@JvmOverloads
fun View.performKeyPressed(keyCode: Int, duration: Long = 150) {
    onKeyDown(keyCode, KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
    Handler(Looper.getMainLooper()).postDelayed({ onKeyUp(keyCode, KeyEvent(KeyEvent.ACTION_UP, keyCode)) }, duration)
}

/**
 * Simulate the touch events.
 *
 * Same like [View.performClick].
 * @receiver [View]
 * @param downX the down x coordinate.
 * @param downY the down y coordinate.
 * @param upX the up x coordinate.
 * @param upY the up y coordinate.
 * @param duration the touching duration time.
 */
fun View.performTouch(downX: Float, downY: Float, upX: Float, upY: Float, duration: Long) {
    val metaState = 0

    val downTime = System.currentTimeMillis()
    val eventTime = downTime + duration
    val motionEventDown = MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_DOWN, downX, downY, metaState)
    val motionEventUp = MotionEvent.obtain(downTime, eventTime, MotionEvent.ACTION_UP, upX, upY, metaState)

    try {
        dispatchTouchEvent(motionEventDown)
        dispatchTouchEvent(motionEventUp)
    } finally {
        motionEventDown.recycle()
        motionEventUp.recycle()
    }
}

/**
 * Set the view's click listener with interval.
 * @see View.setOnClickListener
 * @receiver [View]
 * @param timeMillis the interval time in milliseconds, default is 300.
 * @param listener the click listener.
 */
@JvmOverloads
fun View.setIntervalOnClickListener(timeMillis: Long = 300L, listener: View.OnClickListener) {
    var lastClickTime = 0L

    setOnClickListener { view ->
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime < timeMillis)
            return@setOnClickListener

        lastClickTime = currentTime
        listener.onClick(view)
    }
}

/**
 * Get the view's padding.
 * @see View.setPadding
 * @see View.setPaddingRelative
 * @see ViewPadding
 * @see AbsolutePadding
 * @see RelativePadding
 * @see AxisPadding
 * @see PaddingValues
 * @receiver [View]
 * @return [ViewPadding]
 */
val View.padding get() = ViewPadding(this)

/**
 * Set the view's padding.
 * @see View.setPadding
 * @see View.setPaddingRelative
 * @see ViewPadding
 * @see AbsolutePadding
 * @see RelativePadding
 * @see AxisPadding
 * @see PaddingValues
 * @receiver [View]
 * @param values the padding values.
 */
fun View.setPadding(values: PaddingValues) = values.applyTo(this)

/**
 * Updates this view's horizontal or vertical padding.
 * @see View.updatePadding
 * @receiver [View]
 * @param horizontal the horizontal padding (px).
 * @param vertical the vertical padding (px).
 */
@JvmOverloads
fun View.updatePadding(@Px horizontal: Int = -1, @Px vertical: Int = -1) {
    if (horizontal >= 0) updatePadding(left = horizontal, right = horizontal)
    if (vertical >= 0) updatePadding(top = vertical, bottom = vertical)
}

/**
 * Updates this view's horizontal or vertical padding.
 * @see View.updatePaddingRelative
 * @receiver [View]
 * @param horizontal the horizontal padding (px).
 * @param vertical the vertical padding (px).
 */
@JvmOverloads
fun View.updatePaddingRelative(@Px horizontal: Int = -1, @Px vertical: Int = -1) {
    if (horizontal >= 0) updatePaddingRelative(start = horizontal, end = horizontal)
    if (vertical >= 0) updatePaddingRelative(top = vertical, bottom = vertical)
}

/**
 * Updates this view's margins.
 *
 * This view layout params need to be a [ViewGroup.MarginLayoutParams], if not will be ignored.
 * @see ViewGroup.MarginLayoutParams.updateMargins
 * @receiver [View]
 * @param left the left margin (px).
 * @param top the top margin (px).
 * @param right the right margin (px).
 * @param bottom the bottom margin (px).
 */
@JvmOverloads
fun View.updateMargins(
    @Px left: Int = marginLeft,
    @Px top: Int = marginTop,
    @Px right: Int = marginRight,
    @Px bottom: Int = marginBottom
) {
    if (layoutParams !is ViewGroup.MarginLayoutParams) return

    updateLayoutParams<ViewGroup.MarginLayoutParams> {
        updateMargins(left, top, right, bottom)
    }
}

/**
 * Updates this view's margins.
 *
 * This view layout params need to be a [ViewGroup.MarginLayoutParams], if not will be ignored.
 * @see ViewGroup.MarginLayoutParams.updateMarginsRelative
 * @receiver [View]
 * @param start the start margin (px).
 * @param top the top margin (px).
 * @param end the end margin (px).
 * @param bottom the bottom margin (px).
 */
@JvmOverloads
fun View.updateMarginsRelative(
    @Px start: Int = marginStart,
    @Px top: Int = marginTop,
    @Px end: Int = marginEnd,
    @Px bottom: Int = marginBottom
) {
    if (layoutParams !is ViewGroup.MarginLayoutParams) return

    updateLayoutParams<ViewGroup.MarginLayoutParams> {
        updateMarginsRelative(start, top, end, bottom)
    }
}

/**
 * Updates this view's horizontal or vertical margins.
 *
 * This view layout params need to be a [ViewGroup.MarginLayoutParams], if not will be ignored.
 * @see ViewGroup.MarginLayoutParams.updateMargins
 * @receiver [View]
 * @param horizontal the horizontal margin (px).
 * @param vertical the vertical margin (px).
 */
@JvmOverloads
@JvmName("updateHVMargins")
fun View.updateMargins(@Px horizontal: Int = -1, @Px vertical: Int = -1) {
    if (horizontal >= 0) updateMargins(left = horizontal, right = horizontal)
    if (vertical >= 0) updateMargins(top = vertical, bottom = vertical)
}

/**
 * Updates this view's horizontal or vertical margins.
 * @see ViewGroup.MarginLayoutParams.updateMargins
 * @receiver [ViewGroup.MarginLayoutParams]
 * @param horizontal the horizontal margin (px).
 * @param vertical the vertical margin (px).
 */
@JvmOverloads
fun ViewGroup.MarginLayoutParams.updateMargins(@Px horizontal: Int = -1, @Px vertical: Int = -1) {
    if (horizontal >= 0) updateMargins(left = horizontal, right = horizontal)
    if (vertical >= 0) updateMargins(top = vertical, bottom = vertical)
}

/**
 * Set this view's margins.
 *
 * This view layout params need to be a [ViewGroup.MarginLayoutParams], if not will be ignored.
 * @see ViewGroup.MarginLayoutParams.setMargins
 * @receiver [View]
 * @param left the left margin (px).
 * @param top the top margin (px).
 * @param right the right margin (px).
 * @param bottom the bottom margin (px).
 */
fun View.setMargins(@Px left: Int, @Px top: Int, @Px right: Int, @Px bottom: Int) {
    if (layoutParams !is ViewGroup.MarginLayoutParams) return

    updateLayoutParams<ViewGroup.MarginLayoutParams> {
        setMargins(left, top, right, bottom)
    }
}

/**
 * Set this view's margins.
 *
 * This view layout params need to be a [ViewGroup.MarginLayoutParams], if not will be ignored.
 * @see ViewGroup.MarginLayoutParams.setMargins
 * @receiver [View]
 * @param size the margin size (px).
 */
fun View.setMargins(@Px size: Int) {
    if (layoutParams !is ViewGroup.MarginLayoutParams) return

    updateLayoutParams<ViewGroup.MarginLayoutParams> {
        setMargins(size)
    }
}

/**
 * Walk to the view's parent views.
 * @see View.ancestors
 * @receiver [View]
 * @return [Sequence]<[View]>
 */
fun View.walkToRoot(): Sequence<View> = generateSequence(this) {
    it.parentOrNull()
}

/**
 * Walk through the view's children views.
 * @see ViewGroup.descendants
 * @receiver [ViewGroup]
 * @return [Sequence]<[View]>
 */
fun ViewGroup.walkThroughChildren(): Sequence<View> = sequence {
    children.forEach { child ->
        yield(child)
        if (child is ViewGroup) yieldAll(child.walkThroughChildren())
    }
}

/**
 * Get the view's index in its parent view.
 *
 * If the parent view is not exists, return -1.
 * @see ViewGroup.indexOfChild
 * @receiver [View]
 * @return [Int]
 */
fun View.indexOfInParent() = parentOrNull()?.indexOfChild(this) ?: -1

/**
 * Set the view's outline provider.
 * @receiver [V]
 * @param provider the outline provider callback.
 */
inline fun <reified V : View> V.outlineProvider(crossinline provider: (view: V, outline: Outline) -> Unit) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            provider(view as V, outline)
        }
    }
}

/**
 * Create a new [ViewGroup.LayoutParams].
 *
 * Usage:
 *
 * ```kotlin
 * // Create a LinearLayout.LayoutParams with fully WRAP_CONTENT.
 * val linLayoutParams = ViewLayoutParams<LinearLayout.LayoutParams>()
 * // Create a FrameLayout.LayoutParams with fully MATCH_PARENT.
 * val fraLayoutParams = ViewLayoutParams<FrameLayout.LayoutParams>(matchParent = true)
 * ```
 * @param width the layout params width (px).
 * @param height the layout params height (px).
 * @param matchParent set width and height to [LayoutParamsMatchParent], default false.
 * @param widthMatchParent set width to [LayoutParamsMatchParent], default false.
 * @param heightMatchParent set height to [LayoutParamsMatchParent], default false.
 * @return [LP]
 * @throws IllegalStateException if [LP] create failed.
 */
inline fun <reified LP : ViewGroup.LayoutParams> ViewLayoutParams(
    @Px width: Int? = null,
    @Px height: Int? = null,
    matchParent: Boolean = false,
    widthMatchParent: Boolean = false,
    heightMatchParent: Boolean = false
) = ViewLayoutParams(LP::class, width, height, matchParent, widthMatchParent, heightMatchParent)

/**
 * Create a new [ViewGroup.LayoutParams].
 *
 * Usage:
 *
 * ```kotlin
 * // Create a LinearLayout.LayoutParams with fully WRAP_CONTENT.
 * val linLayoutParams = ViewLayoutParams(LinearLayout.LayoutParams::class)
 * // Create a FrameLayout.LayoutParams with fully MATCH_PARENT.
 * val fraLayoutParams = ViewLayoutParams(FrameLayout.LayoutParams::class, matchParent = true)
 * ```
 * @param lpClass the layout params class.
 * @param width the layout params width (px).
 * @param height the layout params height (px).
 * @param matchParent set width and height to [LayoutParamsMatchParent], default false.
 * @param widthMatchParent set width to [LayoutParamsMatchParent], default false.
 * @param heightMatchParent set height to [LayoutParamsMatchParent], default false.
 * @return [LP]
 * @throws IllegalStateException if [LP] create failed.
 */
@JvmOverloads
fun <LP : ViewGroup.LayoutParams> ViewLayoutParams(
    lpClass: KClass<LP>,
    @Px width: Int? = null,
    @Px height: Int? = null,
    matchParent: Boolean = false,
    widthMatchParent: Boolean = false,
    heightMatchParent: Boolean = false
) = ViewLayoutParams(lpClass.java, width, height, matchParent, widthMatchParent, heightMatchParent)

/**
 * Create a new [ViewGroup.LayoutParams].
 *
 * Usage:
 *
 * ```kotlin
 * // Create a LinearLayout.LayoutParams with fully WRAP_CONTENT.
 * val linLayoutParams = ViewLayoutParams(LinearLayout.LayoutParams::class.java)
 * // Create a FrameLayout.LayoutParams with fully MATCH_PARENT.
 * val fraLayoutParams = ViewLayoutParams(FrameLayout.LayoutParams::class.java, matchParent = true)
 * ```
 * @param lpClass the layout params class.
 * @param width the layout params width (px).
 * @param height the layout params height (px).
 * @param matchParent set width and height to [LayoutParamsMatchParent], default false.
 * @param widthMatchParent set width to [LayoutParamsMatchParent], default false.
 * @param heightMatchParent set height to [LayoutParamsMatchParent], default false.
 * @return [LP]
 * @throws IllegalStateException if [LP] create failed.
 */
@JvmOverloads
fun <LP : ViewGroup.LayoutParams> ViewLayoutParams(
    lpClass: Class<LP>,
    @Px width: Int? = null,
    @Px height: Int? = null,
    matchParent: Boolean = false,
    widthMatchParent: Boolean = false,
    heightMatchParent: Boolean = false
): LP {
    val absWidth = when {
        width != null -> width
        matchParent || widthMatchParent -> LayoutParamsMatchParent
        else -> LayoutParamsWrapContent
    }
    val absHeight = when {
        height != null -> height
        matchParent || heightMatchParent -> LayoutParamsMatchParent
        else -> LayoutParamsWrapContent
    }

    return lpClass.createInstanceOrNull(absWidth, absHeight) ?: error(
        "Create ViewGroup.LayoutParams failed. " +
            "Could not found the default constructor LayoutParams(width, height) in $lpClass."
    )
}

/** Reference to [ViewGroup.LayoutParams.MATCH_PARENT]. */
const val LayoutParamsMatchParent = ViewGroup.LayoutParams.MATCH_PARENT

/** Reference to [ViewGroup.LayoutParams.WRAP_CONTENT]. */
const val LayoutParamsWrapContent = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * The view's padding.
 * @see AbsolutePadding
 * @see RelativePadding
 * @see AxisPadding
 * @see PaddingValues
 */
@JvmInline
value class ViewPadding internal constructor(private val view: View) {

    /**
     * Get or set the view's left padding (px).
     * @return [Int]
     */
    var left: Int
        @Px get() = view.paddingLeft
        set(@Px value) = view.updatePadding(left = value)

    /**
     * Get or set the view's right padding (px).
     * @return [Int]
     */
    var right: Int
        @Px get() = view.paddingRight
        set(@Px value) = view.updatePadding(right = value)

    /**
     * Get or set the view's start padding (px).
     * @return [Int]
     */
    var start: Int
        @Px get() = view.paddingStart
        set(@Px value) = view.updatePaddingRelative(start = value)

    /**
     * Get or set the view's end padding (px).
     * @return [Int]
     */
    var end: Int
        @Px get() = view.paddingEnd
        set(@Px value) = view.updatePaddingRelative(end = value)

    /** Get or set the view's top padding (px). */
    var top: Int
        @Px get() = view.paddingTop
        set(@Px value) = view.updatePadding(top = value)

    /** Get or set the view's bottom padding (px). */
    var bottom: Int
        @Px get() = view.paddingBottom
        set(@Px value) = view.updatePadding(bottom = value)

    /**
     * Get the view's horizontal padding axis.
     * @return [Axis]
     */
    val horizontal get() = Axis(view, AxisType.Horizontal)

    /**
     * Get the view's relative horizontal padding axis.
     * @return [Axis]
     */
    val relativeHorizontal get() = Axis(view, AxisType.RelativeHorizontal)

    /**
     * Get the view's vertical padding axis.
     * @return [Axis]
     */
    val vertical get() = Axis(view, AxisType.Vertical)

    /**
     * Get whether the view's padding is relative.
     * @see View.isPaddingRelative
     * @return [Boolean]
     */
    val isRelative get() = view.isPaddingRelative

    /**
     * Convert to [AbsolutePadding] with current padding values.
     * @return [AbsolutePadding]
     */
    fun toAbsolute() = AbsolutePadding(left, top, right, bottom)

    /**
     * Convert to [RelativePadding] with current padding values.
     * @return [RelativePadding]
     */
    fun toRelative() = RelativePadding(start, top, end, bottom)

    operator fun plusAssign(other: AbsolutePadding) {
        if (other == AbsolutePadding.Zero) return
        view.updatePadding(
            left = view.paddingLeft + other.left,
            top = view.paddingTop + other.top,
            right = view.paddingRight + other.right,
            bottom = view.paddingBottom + other.bottom
        )
    }

    operator fun minusAssign(other: AbsolutePadding) {
        if (other == AbsolutePadding.Zero) return
        view.updatePadding(
            left = view.paddingLeft - other.left,
            top = view.paddingTop - other.top,
            right = view.paddingRight - other.right,
            bottom = view.paddingBottom - other.bottom
        )
    }

    operator fun plusAssign(other: RelativePadding) {
        if (other == RelativePadding.Zero) return
        view.updatePaddingRelative(
            start = view.paddingStart + other.start,
            top = view.paddingTop + other.top,
            end = view.paddingEnd + other.end,
            bottom = view.paddingBottom + other.bottom
        )
    }

    operator fun minusAssign(other: RelativePadding) {
        if (other == RelativePadding.Zero) return
        view.updatePaddingRelative(
            start = view.paddingStart - other.start,
            top = view.paddingTop - other.top,
            end = view.paddingEnd - other.end,
            bottom = view.paddingBottom - other.bottom
        )
    }

    /**
     * Add the [AxisPadding] to the view's current padding.
     * @param other the padding values to add.
     */
    operator fun plusAssign(other: AxisPadding) {
        if (other == AxisPadding.Zero) return
        if (isRelative) view.updatePaddingRelative(
            start = view.paddingStart + other.horizontal,
            top = view.paddingTop + other.vertical,
            end = view.paddingEnd + other.horizontal,
            bottom = view.paddingBottom + other.vertical
        ) else view.updatePadding(
            left = view.paddingLeft + other.horizontal,
            top = view.paddingTop + other.vertical,
            right = view.paddingRight + other.horizontal,
            bottom = view.paddingBottom + other.vertical
        )
    }

    /**
     * Subtract the [AxisPadding] from the view's current padding.
     * @param other the padding values to subtract.
     */
    operator fun minusAssign(other: AxisPadding) {
        if (other == AxisPadding.Zero) return
        if (isRelative) view.updatePaddingRelative(
            start = view.paddingStart - other.horizontal,
            top = view.paddingTop - other.vertical,
            end = view.paddingEnd - other.horizontal,
            bottom = view.paddingBottom - other.vertical
        ) else view.updatePadding(
            left = view.paddingLeft - other.horizontal,
            top = view.paddingTop - other.vertical,
            right = view.paddingRight - other.horizontal,
            bottom = view.paddingBottom - other.vertical
        )
    }

    /**
     * The view's padding axis.
     */
    class Axis internal constructor(private val view: View, private val type: AxisType) {

        /**
         * Set the view's padding axis (px).
         * @param value the padding value.
         */
        fun set(@Px value: Int) = when (type) {
            AxisType.Horizontal -> view.updatePadding(horizontal = value)
            AxisType.RelativeHorizontal -> view.updatePaddingRelative(horizontal = value)
            AxisType.Vertical -> view.updatePadding(vertical = value)
        }

        /**
         * Add the value to the view's current padding axis.
         * @param value the padding value.
         */
        operator fun plusAssign(@Px value: Int) = when (type) {
            AxisType.Horizontal -> view.updatePadding(
                left = view.paddingLeft + value,
                right = view.paddingRight + value
            )
            AxisType.RelativeHorizontal -> view.updatePaddingRelative(
                start = view.paddingStart + value,
                end = view.paddingEnd + value
            )
            AxisType.Vertical -> view.updatePadding(
                top = view.paddingTop + value,
                bottom = view.paddingBottom + value
            )
        }

        /**
         * Subtract the value from the view's current padding axis.
         * @param value the padding value.
         */
        operator fun minusAssign(@Px value: Int) = when (type) {
            AxisType.Horizontal -> view.updatePadding(
                left = view.paddingLeft - value,
                right = view.paddingRight - value
            )
            AxisType.RelativeHorizontal -> view.updatePaddingRelative(
                start = view.paddingStart - value,
                end = view.paddingEnd - value
            )
            AxisType.Vertical -> view.updatePadding(
                top = view.paddingTop - value,
                bottom = view.paddingBottom - value
            )
        }
    }

    /**
     * The view's padding axis type.
     */
    internal enum class AxisType {
        Horizontal,
        RelativeHorizontal,
        Vertical
    }
}

/**
 * The absolute padding values.
 * @see RelativePadding
 * @see AxisPadding
 * @see PaddingValues
 */
data class AbsolutePadding(
    @field:Px val left: Int = 0,
    @field:Px val top: Int = 0,
    @field:Px val right: Int = 0,
    @field:Px val bottom: Int = 0
) : PaddingValues {

    companion object {

        /** The zero padding values. */
        val Zero = AbsolutePadding()
    }

    override fun applyTo(view: View) = view.setPadding(left, top, right, bottom)

    operator fun plus(other: AbsolutePadding) = AbsolutePadding(
        left = left + other.left,
        top = top + other.top,
        right = right + other.right,
        bottom = bottom + other.bottom
    )

    operator fun minus(other: AbsolutePadding) = AbsolutePadding(
        left = left - other.left,
        top = top - other.top,
        right = right - other.right,
        bottom = bottom - other.bottom
    )
}

/**
 * The relative padding values.
 * @see AbsolutePadding
 * @see AxisPadding
 * @see PaddingValues
 */
data class RelativePadding(
    @field:Px val start: Int = 0,
    @field:Px val top: Int = 0,
    @field:Px val end: Int = 0,
    @field:Px val bottom: Int = 0
) : PaddingValues {

    companion object {

        /** The zero padding values. */
        val Zero = RelativePadding()
    }

    override fun applyTo(view: View) = view.setPaddingRelative(start, top, end, bottom)

    operator fun plus(other: RelativePadding) = RelativePadding(
        start = start + other.start,
        top = top + other.top,
        end = end + other.end,
        bottom = bottom + other.bottom
    )

    operator fun minus(other: RelativePadding) = RelativePadding(
        start = start - other.start,
        top = top - other.top,
        end = end - other.end,
        bottom = bottom - other.bottom
    )
}

/**
 * The axis padding values.
 * @see AbsolutePadding
 * @see RelativePadding
 * @see PaddingValues
 */
data class AxisPadding(
    @field:Px val horizontal: Int = 0,
    @field:Px val vertical: Int = 0
) : PaddingValues {

    companion object {

        /** The zero padding values. */
        val Zero = AxisPadding()
    }

    override fun applyTo(view: View) = if (view.isPaddingRelative)
        view.updatePaddingRelative(horizontal = horizontal, vertical = vertical)
    else view.updatePadding(horizontal = horizontal, vertical = vertical)

    /**
     * Add another [AxisPadding].
     * @param other the padding values to add.
     * @return [AxisPadding]
     */
    operator fun plus(other: AxisPadding) = AxisPadding(
        horizontal = horizontal + other.horizontal,
        vertical = vertical + other.vertical
    )

    /**
     * Subtract another [AxisPadding].
     * @param other the padding values to subtract.
     * @return [AxisPadding]
     */
    operator fun minus(other: AxisPadding) = AxisPadding(
        horizontal = horizontal - other.horizontal,
        vertical = vertical - other.vertical
    )
}

/**
 * The padding values.
 */
sealed interface PaddingValues {

    /**
     * Apply the padding values to the view.
     * @param view the target view.
     */
    fun applyTo(view: View)
}